import pygame
import random
from hand_tracking import HandDetector

pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

alien = pygame.image.load('image/alienYellow.png')
alien_walk1 = pygame.image.load('image/alienYellow_walk1.png')

x = 400
y = 300
score = 0

crystal_x = [random.randint(0, 800) for _ in range(5)]
crystal_y = [random.randint(0, 600) for _ in range(5)]

detector = HandDetector()
font = pygame.font.Font(None, 36)

game = True
while game:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game = False
    
    move, cam = detector.get_command()
    
    if move:
        if move['x'] != 0:
            x += move['x'] * 5
        if move['y'] != 0:
            y += move['y'] * 5
    
    if x < 0: x = 0
    if x > 750: x = 750
    if y < 0: y = 0
    if y > 550: y = 550
    
    for i in range(5):
        if abs(x - crystal_x[i]) < 30 and abs(y - crystal_y[i]) < 30:
            score += 1
            crystal_x[i] = random.randint(0, 800)
            crystal_y[i] = random.randint(0, 600)
    
    screen.fill((20, 20, 40))
    
    for i in range(5):
        pygame.draw.rect(screen, (147, 112, 219), (crystal_x[i], crystal_y[i], 15, 15))
    
    screen.blit(alien, (x, y))
    screen.blit(font.render(f'Кристали: {score}', True, (255, 255, 255)), (10, 10))
    
    if cam is not None:
        screen.blit(pygame.surfarray.make_surface(cam), (640, 10))
    
    pygame.display.flip()
    clock.tick(60)

detector.cleanup()
pygame.quit()
